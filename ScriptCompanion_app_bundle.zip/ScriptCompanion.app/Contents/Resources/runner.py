from __future__ import annotations
import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from policy import RunnerPolicy

@dataclass
class RunResult:
    returncode: int
    stdout: str
    stderr: str
    duration_seconds: float
    working_directory: str
    python_used: str

class ScriptRunner:
    def __init__(self, app_home: str | Path, resource_root: str | Path):
        self.app_home = Path(app_home).resolve()
        self.resource_root = Path(resource_root).resolve()
        self.bootstrap_file = self.resource_root / "bootstrap.py"
        self.runs_dir = self.app_home / "runs"
        self.runs_dir.mkdir(parents=True, exist_ok=True)

    def prepare_working_dir(self, script_path: Path, policy: RunnerPolicy) -> Path:
        temp_dir = Path(tempfile.mkdtemp(prefix="script_companion_", dir=str(self.runs_dir)))
        if policy.working_directory_mode == "copy_script_folder":
            src_dir = script_path.parent
            for item in src_dir.iterdir():
                dst = temp_dir / item.name
                if item.is_dir():
                    shutil.copytree(item, dst, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, dst)
            return temp_dir
        shutil.copy2(script_path, temp_dir / script_path.name)
        return temp_dir

    def build_env(self, policy: RunnerPolicy) -> dict[str, str]:
        clean_env = {}
        for key in policy.allowed_env:
            if key in os.environ:
                clean_env[key] = os.environ[key]
        clean_env["PYTHONUNBUFFERED"] = "1"
        clean_env["SR_ALLOWED_IMPORTS"] = ",".join(policy.allowed_imports)
        clean_env["SR_BLOCKED_IMPORTS"] = ",".join(policy.blocked_imports)
        clean_env["SR_NETWORK"] = "1" if policy.network else "0"
        return clean_env

    def run_script(self, script_path: str | Path, policy: RunnerPolicy) -> RunResult:
        original_script = Path(script_path).resolve()
        if not original_script.exists():
            raise FileNotFoundError(original_script)
        work_dir = self.prepare_working_dir(original_script, policy)
        work_script = work_dir / original_script.name
        chosen_python = Path(policy.python_executable).expanduser().resolve() if policy.python_executable else Path(os.environ.get("PYTHON_EXECUTABLE_FOR_APP", os.sys.executable)).resolve()
        env = self.build_env(policy)
        cmd = [str(chosen_python), str(self.bootstrap_file), str(work_script)]
        start = time.perf_counter()
        try:
            proc = subprocess.run(cmd, cwd=str(work_dir), capture_output=True, text=True, timeout=policy.timeout_seconds, env=env)
            end = time.perf_counter()
            return RunResult(proc.returncode, proc.stdout, proc.stderr, end - start, str(work_dir), str(chosen_python))
        except subprocess.TimeoutExpired as exc:
            end = time.perf_counter()
            return RunResult(-9, exc.stdout or "", (exc.stderr or "") + f"\nTimed out after {policy.timeout_seconds} seconds.", end - start, str(work_dir), str(chosen_python))
