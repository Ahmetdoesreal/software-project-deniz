from __future__ import annotations
import builtins
import os
import runpy
import socket
import sys
from pathlib import Path


def _read_policy_from_env() -> dict:
    allowed = os.environ.get("SR_ALLOWED_IMPORTS", "")
    blocked = os.environ.get("SR_BLOCKED_IMPORTS", "")
    network_enabled = os.environ.get("SR_NETWORK", "0") == "1"
    return {
        "allowed_imports": {x.strip() for x in allowed.split(",") if x.strip()},
        "blocked_imports": {x.strip() for x in blocked.split(",") if x.strip()},
        "network": network_enabled,
    }


def _patch_imports(policy: dict) -> None:
    original_import = builtins.__import__
    allowed = policy["allowed_imports"]
    blocked = policy["blocked_imports"]

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        root_name = name.split(".")[0]
        if root_name in blocked:
            raise ImportError(f"Blocked import by policy: {root_name}")
        if allowed and root_name not in allowed:
            raise ImportError(f"Import not allowed by policy: {root_name}")
        return original_import(name, globals, locals, fromlist, level)

    builtins.__import__ = guarded_import


def _patch_network(policy: dict) -> None:
    if policy["network"]:
        return
    def blocked(*args, **kwargs):
        raise PermissionError("Network access is disabled by runner policy.")
    socket.socket = blocked
    socket.create_connection = blocked
    if hasattr(socket, "fromfd"):
        socket.fromfd = blocked
    if hasattr(socket, "socketpair"):
        socket.socketpair = blocked


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit("Usage: bootstrap.py <script_path>")
    script_path = Path(sys.argv[1]).resolve()
    if not script_path.exists():
        raise FileNotFoundError(script_path)
    policy = _read_policy_from_env()
    _patch_imports(policy)
    _patch_network(policy)
    sys.argv = [str(script_path)]
    runpy.run_path(str(script_path), run_name="__main__")


if __name__ == "__main__":
    main()
