from __future__ import annotations
import json
from dataclasses import dataclass, field
from pathlib import Path

@dataclass
class RunnerPolicy:
    timeout_seconds: int = 30
    network: bool = False
    allowed_imports: list[str] = field(default_factory=list)
    blocked_imports: list[str] = field(default_factory=list)
    allowed_env: list[str] = field(default_factory=list)
    working_directory_mode: str = "copy_script_folder"
    python_executable: str = ""


def load_policy(policy_path: str | Path) -> RunnerPolicy:
    path = Path(policy_path)
    data = json.loads(path.read_text(encoding="utf-8"))
    return RunnerPolicy(
        timeout_seconds=int(data.get("timeout_seconds", 30)),
        network=bool(data.get("network", False)),
        allowed_imports=list(data.get("allowed_imports", [])),
        blocked_imports=list(data.get("blocked_imports", [])),
        allowed_env=list(data.get("allowed_env", [])),
        working_directory_mode=str(data.get("working_directory_mode", "copy_script_folder")),
        python_executable=str(data.get("python_executable", "")),
    )
