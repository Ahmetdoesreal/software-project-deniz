from __future__ import annotations
import json
import os
import sys
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from policy import load_policy
from runner import ScriptRunner

RESOURCE_ROOT = Path(__file__).resolve().parent
APP_HOME = Path(os.environ.get("SCRIPT_COMPANION_HOME", str(Path.home() / "Library/Application Support/ScriptCompanion"))).resolve()
APP_HOME.mkdir(parents=True, exist_ok=True)
POLICY_PATH = APP_HOME / "default_policy.json"
if not POLICY_PATH.exists():
    POLICY_PATH.write_text((RESOURCE_ROOT / "default_policy.json").read_text(encoding="utf-8"), encoding="utf-8")

class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("ScriptCompanion")
        self.geometry("1020x760")
        self.minsize(800, 600)

        os.environ["PYTHON_EXECUTABLE_FOR_APP"] = sys.executable
        self.runner = ScriptRunner(APP_HOME, RESOURCE_ROOT)
        self.script_var = tk.StringVar()
        self.policy_var = tk.StringVar(value=str(POLICY_PATH))
        self._build_ui()

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Python script").grid(row=0, column=0, sticky="w")
        ttk.Entry(outer, textvariable=self.script_var).grid(row=1, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(outer, text="Browse", command=self.browse_script).grid(row=1, column=1, sticky="ew")

        ttk.Label(outer, text="Policy JSON").grid(row=2, column=0, sticky="w", pady=(12, 0))
        ttk.Entry(outer, textvariable=self.policy_var).grid(row=3, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(outer, text="Browse", command=self.browse_policy).grid(row=3, column=1, sticky="ew")

        actions = ttk.Frame(outer)
        actions.grid(row=4, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Button(actions, text="Run Script", command=self.run_script).pack(side="left")
        ttk.Button(actions, text="Open App Home", command=self.open_app_home).pack(side="left", padx=(8,0))
        ttk.Button(actions, text="Reset Default Policy", command=self.reset_default_policy).pack(side="left", padx=(8,0))

        info_frame = ttk.LabelFrame(outer, text="Run info", padding=10)
        info_frame.grid(row=5, column=0, columnspan=2, sticky="nsew")
        self.info_text = tk.Text(info_frame, height=8, wrap="word")
        self.info_text.pack(fill="both", expand=True)

        output_frame = ttk.LabelFrame(outer, text="Output", padding=10)
        output_frame.grid(row=6, column=0, columnspan=2, sticky="nsew", pady=(12, 0))
        self.output_text = tk.Text(output_frame, wrap="word")
        self.output_text.pack(fill="both", expand=True)

        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(6, weight=1)
        self.info_text.insert("end", f"Ready. App home: {APP_HOME}\n")

    def browse_script(self) -> None:
        path = filedialog.askopenfilename(title="Choose Python Script", filetypes=[("Python files", "*.py"), ("All files", "*.*")])
        if path:
            self.script_var.set(path)

    def browse_policy(self) -> None:
        path = filedialog.askopenfilename(title="Choose Policy File", filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
        if path:
            self.policy_var.set(path)

    def write_info(self, text: str) -> None:
        self.info_text.delete("1.0", "end")
        self.info_text.insert("end", text)

    def write_output(self, text: str) -> None:
        self.output_text.delete("1.0", "end")
        self.output_text.insert("end", text)

    def open_app_home(self) -> None:
        path = APP_HOME
        if sys.platform == "darwin":
            os.system(f'open "{path}"')
        else:
            messagebox.showinfo("App home", str(path))

    def reset_default_policy(self) -> None:
        POLICY_PATH.write_text((RESOURCE_ROOT / "default_policy.json").read_text(encoding="utf-8"), encoding="utf-8")
        self.policy_var.set(str(POLICY_PATH))
        messagebox.showinfo("Policy reset", f"Reset:\n{POLICY_PATH}")

    def run_script(self) -> None:
        script_path = self.script_var.get().strip()
        policy_path = self.policy_var.get().strip()
        if not script_path:
            messagebox.showerror("Missing script", "Select a Python script first.")
            return
        if not Path(script_path).exists():
            messagebox.showerror("Missing script", "The selected script does not exist.")
            return
        if not Path(policy_path).exists():
            messagebox.showerror("Missing policy", "The selected policy file does not exist.")
            return
        try:
            policy = load_policy(policy_path)
            result = self.runner.run_script(script_path, policy)
            info = (
                f"Return code: {result.returncode}\n"
                f"Duration: {result.duration_seconds:.2f}s\n"
                f"Working directory: {result.working_directory}\n"
                f"Python used: {result.python_used}\n"
                f"Policy: {policy_path}\n"
            )
            output = "=== STDOUT ===\n" + result.stdout + "\n\n=== STDERR ===\n" + result.stderr + "\n"
            self.write_info(info)
            self.write_output(output)
        except Exception as exc:
            self.write_info("Runner failed.")
            self.write_output(f"{exc}\n\n{traceback.format_exc()}")

if __name__ == "__main__":
    App().mainloop()
